
//    COMPILERS LABORATORY CS39003
//    ASSIGNMENT O4 -- Parser for tinyC
//    Semester O5 (Autumn 2023-24)
//    Group Members :	Tohuto Sema (21CS10072)
//				Abhishek Singh Maurya (21CS10001)

extern int yyparse();

int main() 
{
    yyparse();
    return 0;
}
